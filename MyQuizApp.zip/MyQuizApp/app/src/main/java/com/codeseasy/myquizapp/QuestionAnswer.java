package com.codeseasy.myquizapp;

public class QuestionAnswer {

    public static String question[] ={
            "What is the time complexity of searching for an element in a balanced binary search tree (BST)?",
            "Which data structure is best suited for implementing a LIFO (Last-In-First-Out) behavior?",
            "In which sorting algorithm is the worst-case time complexity O(n^2) in the worst case but can be optimized to O(n log n) in the average case?",
            "What is the space complexity of a typical recursive algorithm?",
            "Which data structure is typically used to implement a priority queue?",
            "What is the time complexity of the best-case scenario for the bubble sort algorithm?",
            "In which data structure is data accessed in a non-linear fashion?",
            "Which search algorithm works by repeatedly dividing the search interval in half?",
            "What is the primary advantage of using a hash table data structure?",
            "Which sorting algorithm is known for its stability, meaning that it preserves the relative order of equal elements?"




    };

    public static String choices[][] ={
            {"O(1)","O(log N)","O(N)","O(N^2)"},
            {"Queue","Stack","Linked List","Heap"},
            {"Bubble Sort","Insertion Sort","Quick Sort","Merge Sort"},
            {"O(1)"," O(log N)"," O(N)","O(N^2)"},
            {"Queue","Stack","Linked List","Heap"},
            {"O(1)","O(N)","O(N log N)","O(N^2)"},
            {"Array","Linked List","Stack","Queue"},
            {"Linear Search","Binary Search","Depth-First Search","Breadth-First Search"},
            {"Constant time access for any element","Sorted order of element","Minimal memory usage","Linear time access for any element"},
            {"Quick Sort","Heap Sort","Merge Sort","Bubble Sort"}

    };

    public static String correctAnswers[] ={
            "O(log N)",
            "Stack",
            "Quick Sort",
            "O(log N)",
            "Heap",
            "O(N)",
            "Linked List",
            "Binary Search",
            "Constant time access for any element",
            "Merge Sort"



    };

}
